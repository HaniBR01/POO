class Personagem:

    def __init__(self, nome, classe, ataque, arma, magia):
        self.nome = nome
        self.classe = classe
        self.ataque = ataque
        self.arma = arma
        self.magia = magia

    def atacar(self, texto):
        print(f'{texto} {self.nome} ataca com {self.arma}, causando {self.ataque} pontos de dano.')

personagem = Personagem('Niro', 'clérigo', 2, 'espada', 'cura')
personagem.atacar('Então')