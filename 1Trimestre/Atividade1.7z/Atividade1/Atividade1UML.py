class Caneta:

    def __init__(self, marca, cor, tampada):
        self.marca = marca
        self.cor = cor
        self.tampada = tampada

    def escreve(self, texto):
        print(texto + '(na cor ' + self.cor + ')')

exemplo1 = Caneta('bic', 'vermelha', True)
exemplo2 = Caneta('faber castel', 'azul', False)

exemplo1.escreve('lindo dia ')
exemplo1.escreve('bora sair ')
exemplo2.escreve('ainda não ')