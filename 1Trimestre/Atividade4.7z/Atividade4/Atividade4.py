class Arma:

    def __init__(self, nomeA, tipo):
        self.nomeA = nomeA
        self.tipo = tipo
    
    def PrintArma(self, texto):
        return (texto, self.nomeA, self.tipo)

class Personagem:

    def __init__(self, n, r, c):
        self.nome = n
        self.raca = r
        self.classe = c
        self.armas = []

    def possui(self, arma):
        self.armas += [arma]

    def printpersonagem(self):
        texto = (f"O personagem {self.nome} pertence a raça {self.raca} e é da classe {self.classe}. Sua principal arma é {self.armas[0].nomeA}.")
        return texto

class Guilda:

    def __init__(self, nome, rank):
        self.nome = nome
        self.rank = rank
        self.listaMembros = []

    def addMembro(self, membro):
        self.listaMembros += [membro]
        return self.listaMembros

JogA = Personagem('Niro', 'meio elfo', 'clérigo')
ArmaAa = Arma('Espada de Hades', 'mágica')
ArmaAb = Arma('Convocar Relâmpagos', 'Magia')
JogB = Personagem('Mindartes', 'Alto Elfo', 'Patrulheiro')
ArmaBa = Arma('Arco', 'Fisico')
ArmaBb = Arma('Lâmina Eterea', 'Magica')
JogC = Personagem('Shamash', 'Dragonato', 'Guerreiro')
ArmaCa = Arma('Rapieira', 'Fisico')
ArmaCb = Arma('Besta Leve', 'Fisico')
ArmaCc = Arma('Duas Espadas Curtas', 'Fisico')
JogD = Personagem('Glar', 'Humano', 'Guerreiro')
ArmaDa = Arma('Espadão', 'Fisico')

JogA.possui(ArmaAa)
JogA.possui(ArmaAb)
JogB.possui(ArmaBa)
JogB.possui(ArmaBb)
JogC.possui(ArmaCa)
JogC.possui(ArmaCb)
JogC.possui(ArmaCc)
JogD.possui(ArmaDa)

caju = Guilda('CAJU', 'B2')
caju.addMembro(JogA)
caju.addMembro(JogB)
caju.addMembro(JogC)
caju.addMembro(JogD)

for i in range(len(caju.listaMembros)):
    print(caju.listaMembros[i].printpersonagem())

#É baseado em um rpg de mesa do qual participamos durante a quarentena :)