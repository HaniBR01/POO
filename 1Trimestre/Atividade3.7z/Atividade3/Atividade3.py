class Arma:

    def __init__(self, nomeA, tipo):
        self.nomeA = nomeA
        self.tipo = tipo

class Personagem:

    def __init__(self, n, r, c):
        self.nome = n
        self.raca = r
        self.classe = c
        self.armas = []

    def possui(self, arma):
        self.armas += [arma]

objetop = Personagem('Niro', 'meio elfo', 'clérigo')

exemplo = Arma('Hades', 'mágica')

objetop.possui(exemplo)
print(objetop.armas[0].nomeA)