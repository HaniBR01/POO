from Banco.Conta import conta

if __name__ == "__main__":
    minhaconta = conta("16883-5", "Moises Henrique Ramos Pereira", 12000)
    print(f"saldo atual de {minhaconta.titular}: {minhaconta.saldo}")