class conta:
    def __init__(self, numero, nome, valor):
        self.__numero = numero
        self.__titular = nome
        self.__saldo = valor

    @property
    def numero(self):
        return self.__numero

    @property
    def titular(self):
        partesnome = self.__titular.split(" ")
        tamanho = len(partesnome)
        return partesnome[0] + " " + partesnome[tamanho-1]

    @titular.setter
    def titular(self, nome):
        self.__titular = nome

    @property
    def saldo(self):
        return self.__saldo
    
    '''@saldo.setter 
    def saldo(self, saldo):
        if saldo < 0:
            print('não foi possivel atualizar o valor >=/')
        else:
            self.__saldo = saldo '''

    def sacar(self, valor):
        if valor > self.__saldo:
            print("Não foi possivel sacar")
        else:
            self.__saldo -= valor
            
    def depositar(self, valor):
        if valor < 0:
            print("Não foi possivel depositar")
        else:
            self.__saldo += valor