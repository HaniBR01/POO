class Carteira:

    def __init__ (self, investimentos): # metodo construtor da classe
        self.__investimentos = investimentos
        self.__listaContas = []

    @property # retorna o nome do investimento
    def investimentos(self):
        return self.__investimentos

    @investimentos.setter # altera o nome do investimento
    def investimentos(self, investimentos):
        self.__investimentos = investimentos

    @property # retorna a lista de contas
    def listaContas(self):
        return self.__listaContas

    def addconta(self, objetoconta): # adiciona uma conta existente, tem limite de 3
        if len(self.__listaContas) == 3:
            print("Não é possivel ter mais de 3 contas")
        else:
            self.__listaContas += [objetoconta]

    def contasNegativas(self): # mostra quantas contas tem saldo negativo
        listaNegativas = []
        for continha in self.__listaContas:
            if continha.saldo < 0:
                listaNegativas += [continha]
        if len(listaNegativas) == 0:
            print("Nenhuma conta está negativa \N{slightly smiling face}")
        return listaNegativas
