class Conta:

    def __init__(self, numero, nome, valor): # metodo construtor da super classe
        self.__numero = numero
        self.__titular = nome
        self.__saldo = valor

    @property # retorna o numero
    def numero(self):
        return self.__numero

    @property # retorna o nome do titular
    def titular(self):
        partesnome = self.__titular.split(" ")
        tamanho = len(partesnome)
        return partesnome[0] + " " + partesnome[tamanho-1]

    @titular.setter # permite altera o nome do titular 
    def titular(self, nome):
        self.__titular = nome

    @property # retorna o saldo
    def saldo(self):
        return self.__saldo
    
    @saldo.setter # permite altera o saldo
    def saldo(self, valor):
        if valor < 0:
            print('Não foi possivel atualizar o valor')
        else:
            self.__saldo = valor

    def sacar(self, valor): # realiza a ação de sacar tirando o valor do saldo
        if valor > self.__saldo:
            print("Não foi possivel sacar")
        else:
            self.__saldo -= valor
            
    def depositar(self, valor): # acresenta o valor ao saldo
        if valor < 0:
            print("Não foi possivel depositar")
        else:
            self.__saldo += valor

    def retornadados(self): # retorna todos os dados em uma string
        return f"Número: {self.__numero}\nNome do titular: {self.__titular}\nSaldo da conta: {self.__saldo}\n"

class ContaCorrente(Conta):
    
    contador = 0 # usado para contar quantas classes ContaCorrente existem

    def __init__(self, numero, nome, valor): # metodo construtor da subclasse usa parte da super classe
        super().__init__(numero, nome, valor)
        self.__limite = 2000
        ContaCorrente.contador += 1
    
    @property # retorna o limite
    def limite(self):
        return self.__limite

    @limite.setter  # permite alterar o limite
    def limite(self, limite):
        if limite < 0:
            print('Não foi possivel atualizar o limite')
        else:
            self.__limite = limite

    def saldototal(self): # retorna o saldo + limite
        return self.saldo + self.__limite
    
    def sacar(self, valor): # realiza a ação de sacar contando com o limite
        if valor > self.saldototal():
            print("Não foi possivel sacar")
        else:
            if valor <= self.saldo:
                self.__saldo -= valor
            else:
                self.limite = (valor - self.saldo)
                self.salf = 0

    def retornadados(self): # retorna todos os dados em uma string, usa parte da super classe
        return super().retornadados() + f"Limite: {self.__limite}\n\n"

class ContaPoupanca(Conta):

    def __init__(self, numero, nome, valor, rendimento): # metodo construtor da subclasse usa parte da super classe
        super().__init__(numero, nome, valor)
        self.__rendimento = rendimento

    @property # mostra o rendimento
    def rendimento(self):
        return self.__rendimento

    @rendimento.setter # permite alterar o rendimento
    def rendimento(self, rendimento):
        if rendimento < 0:
            print('não foi possivel atualizar a taxa de rendimento')
        else:
            self.__rendimento = rendimento

    def acaorendimento(self): # realiza a ação do rendimento no saldo
        self.saldo *= self.__rendimento

    def retornadados(self): # retorna dados em uma string, usa parte da super classe
        return super().retornadados() + f"Rendimento: {self.rendimento}\n\n"
