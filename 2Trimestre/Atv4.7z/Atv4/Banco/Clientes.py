from datetime import *

class Cliente:
    
    def __init__ (self, nome, data, endereco): # metodo construtor da super classe usa parametros para guardar dados
        self.__nome = nome
        self.__datanascimento = data
        self.__endereco = endereco
        self.listacarteira = []

    @property # retorna nome
    def nome(self):
        return self.__nome

    @nome.setter # permite alterar o nome
    def nome(self, nome):
        self.__nome = nome

    @property # mostra a data de nascimento
    def datanascimento(self):
        return self.__datanascimento

    @property # mostra o endereço
    def endereco(self):
        return self.__endereco
    
    @endereco.setter # permite alterar o endereço
    def endereco(self, endereco):
        self.__endereco = endereco

    def todosdados(self): # guarda os dados em lista para facilitar buscas
        return [self.__nome, self.__datanascimento, self.__endereco]

    def MostraTudo(self): # retorna todos os dados em uma string
        return f"Nome: {self.__nome}\nData de nascimento: {self.__datanascimento}\nEndereço: {self.__endereco}\n"

    def addcarteira(self, carteira): # adiciona uma carteira
        self.listacarteira += [carteira]

class PessoaFisica(Cliente):
    
    def __init__(self, nome, data, endereco, cpf): # metodo construtor da subclasse, usa parte da super classe
        super().__init__(nome, data, endereco)
        self.__CPF = cpf

    @property # retorna CPF
    def CPF(self):
        return self.__CPF

    def maiorlegal(self): # utiliza a biblioteca datetime para pegar a data atual e depois calcular
        datan = self.datanascimento.split("/")
        data = date.today()
        data = data.strftime('%d/%m/%Y')
        data = data.split("/")
        if ((int(data[2])) - (int(datan[2]))) < 18:
            return False # se a diferença de anos for menor que 18 ja retorna falso
        elif (((int(data[2])) - (int(datan[2]))) == 18) and ((int(data[1])) < (int(datan[1]))):
            return False # se a a diferença de anos for igual a 18 mas o mes for menor retorna falso
        elif (((int(data[2])) - (int(datan[2]))) == 18) and ((int(data[1])) == (int(datan[1]))) and ((int(data[0])) < (int(datan[0]))):
            return False # se a diferença de anos = 18 e mes for igual mas o dia ainda é menor retorna falso
        else:
            return True # se não foi nenhum desses casos retorna verdadeiro

    def todosdados(self): # esse metodo coloca todos os dados em lista para facilitar quando procurar por dados
        return [self.nome, self.datanascimento, self.endereco, self.__CPF]

    def MostraTudo(self): # esse metodo pega o MostraTudo da super classe e adiciona CNJP e tipoSociedade
        return super().MostraTudo() + f"CPF: {self.__CPF}\nMaior legal? {self.maiorlegal()}\n\n"

class PessoaJuridica(Cliente):
    
    def __init__(self, nome, data, endereco, cnpj): # metodo construtor da subclasse, usa parte da super classe
        super().__init__(nome, data, endereco)
        self.__CNPJ = cnpj

    @property # retorna CNPJ
    def CNPJ(self):
        return self.__CNPJ

    def TipoSociedade(self): # esse metodo usa o find par procurar pelo tipo de sociedade se não encontrar retorna -1
        nome = self.nome
        if nome.find('LTDA') > -1:
            return 'Sociedade Limitada'
        elif nome.find('S/A') > -1:
            return 'Sociedade Anônima'
        else:
            return 'Indefinido: Consulte o gerente para regularizar a situação'

    def todosdados(self): # esse metodo coloca todos os dados em lista para facilitar quando procurar por dados
        return [self.nome, self.datanascimento, self.endereco, self.__CNPJ]

    def MostraTudo(self): # esse metodo pega o MostraTudo da super classe e adiciona CNJP e tipoSociedade
        return super().MostraTudo() + f"CNPJ: {self.__CNPJ}\nTipo de sociedade: {self.TipoSociedade()}\n\n"
