from Modulo.Classes import caneta, papelaria

if __name__ == "__main__":
    while True:
        marca = input("Qual a marca? ")
        cor = input("Qual cor? ")
        tampada = input("está tampada? SIM ou NÃO")
        if tampada == "SIM":
            tampada = True
        else:
            tampada = False
        preco = float(input("Qual o preco? "))
        c1 = caneta(marca, cor, tampada, preco)
        p1 = papelaria("calunga", "12.324.121/0001-12", "minas shopping")
        p1.addcaneta(c1)
        print(p1.listacaneta[0].marca)
        continua = input("deseja continuar? SIM ou NÃO")
        if continua == "SIM":
            True
        else:
            break