class caneta:

    def __init__(self, marca, cor, tampada, preco):
        self.__marca = marca
        self.__cor = cor
        self.__tampada = tampada
        self.__preco = preco

    @property
    def marca(self):
        return self.__marca

    @property
    def cor(self):
        return self.__cor

    @property
    def tampada(self):
        return self.__tampada

    @property
    def preco(self):
        return self.__preco

    @tampada.setter
    def tampada(self, vf):
        if vf == True:
            self.__tampada = True
        else:
            self.__tampada = False

    @preco.setter
    def preco(self, valor):
        self.__preco = valor

    def escreve(self, texto):
        print(texto + ' (na cor ' + self.__cor + ')')

class papelaria:
    def __init__ (self, nome, cnpj, endereco):
        self.__nome = nome
        self.__cnpj = cnpj
        self.__endereco = endereco
        self.__listacaneta = []

    @property
    def nome(self):
        return self.__nome

    @property
    def cnpj(self):
        return self.__cnpj

    @property
    def endereco(self):
        return self.__endereco
        
    @property
    def listacaneta(self):
        return self.__listacaneta

    def addcaneta(self, caneta):
        self.__listacaneta += [caneta]
        