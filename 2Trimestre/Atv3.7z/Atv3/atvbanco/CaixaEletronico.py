from Banco.Conta import *
import os
if __name__ == "__main__":
    listaCarteiras = []
    print("Bem-vindo ao bank POOdle \U0001F60E\n ")
    while True:
        print("(1) Cadastrar uma nova carteira \U0001F4B0")
        print("(2) Listar as contas de uma carteira existente \U0001F4B3")
        print("(3) Sair do programa \U0001F44B\n")
        opcao = int(input("\U0001F4AC Informe a opção desejada: "))
        if opcao == 1:
            inv = input("\U0001F4AC Informe o tipo de investimento: ")
            car = Carteira(inv)
            res = input("\U0001F4AC Deseja cadastrar uma conta? s/n ")
            while res == 's':
                num = input("\U0001F4AC Informe o número do titular: ")
                tit = input("\U0001F4AC Informe o nome no titular: ")
                sld = float(input("\U0001F4AC Informe o saldo inicial: "))
                tip = input("\U0001F4AC Qual tipo de conta? Conta Normal (N), Conta Corrente (C), Conta Poupança (P)? ")
                if tip == 'N':
                    car.addconta(Conta(num, tit, sld))
                elif tip == 'C':
                    car.addconta(ContaCorrente(num, tit, sld))
                elif tip == 'P':
                    rnd = float(input("\U0001F4AC Informe o rendimento: "))
                    car.addconta(ContaPoupanca(num, tit, sld, rnd))
                else:
                    print('Opção inválida! \U0001F620')
                res = input("\U0001F4AC Deseja cadastrar uma conta? s/n ")
            listaCarteiras += [car]
        elif opcao == 2:
            inv = input("\U0001F4AC Informe o investimento desejado: ")
            achou = False
            for carteirinha in listaCarteiras:
                if carteirinha.investimentos == inv:
                    achou = True
                    if carteirinha.listaContas == []:
                        print("Essa carteira não possui contas registradas \U0001F62C.")
                    else:
                        for continha in carteirinha.listaContas:
                            print(continha.retornadados())
            if not achou:
                print("Não existe carteira do tipo informado \U0001F62C.")
        elif opcao == 3:
            break
        else:
            print("Opção invalida! \U0001F620")
        input()
        os.system("cls" if os.name == "nt" else "clear")
    print("Volte sempre ao Bank POOdle! \U0001F920")