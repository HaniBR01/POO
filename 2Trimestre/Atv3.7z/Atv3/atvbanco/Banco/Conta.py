class Carteira:

    def __init__ (self, investimentos):
        self.__investimentos = investimentos
        self.__listaContas = []

    @property
    def investimentos(self):
        return self.__investimentos

    @investimentos.setter
    def investimentos(self, valor):
        self.__investimentos = valor

    @property
    def listaContas(self):
        return self.__listaContas

    def addconta(self, objetoconta):
        if len(self.__listaContas) == 3:
            print("Não é possivel ter mais de 3 contas \U0001F614.")
        else:
            self.__listaContas += [objetoconta]

    def contasNegativas(self):
        listaNegativas = []
        for continha in self.__listaContas:
            if continha.saldo < 0:
                listaNegativas += [continha]
        if len(listaNegativas) == 0:
            print("Nenhuma conta está negativa \N{slightly smiling face}")
        return listaNegativas

class Conta:

    def __init__(self, numero, nome, valor):
        self.__numero = numero
        self.__titular = nome
        self.__saldo = valor

    @property
    def numero(self):
        return self.__numero

    @property
    def titular(self):
        partesnome = self.__titular.split(" ")
        tamanho = len(partesnome)
        return partesnome[0] + " " + partesnome[tamanho-1]

    @titular.setter
    def titular(self, nome):
        self.__titular = nome

    @property
    def saldo(self):
        return self.__saldo
    
    @saldo.setter
    def saldo(self, valor):
        if valor < 0:
            print('Não foi possivel atualizar o valor \U0001F614.')
        else:
            self.__saldo = valor

    def sacar(self, valor):
        if valor > self.__saldo:
            print("Não foi possivel sacar \U0001F614.")
        else:
            self.__saldo -= valor
            
    def depositar(self, valor):
        if valor < 0:
            print("Não foi possivel depositar \U0001F614.")
        else:
            self.__saldo += valor

    def retornadados(self):
        return "Número: " + self.__numero + "\n" + "Nome do titular: " + self.__titular + "\n" + "Saldo da conta: " + str(self.__saldo) + "\n\U0001F9D0\n"

class ContaCorrente(Conta):
    
    contador = 0

    def __init__(self, numero, nome, valor):
        super().__init__(numero, nome, valor)
        self.__limite = 2000
        ContaCorrente.contador += 1
    
    @property
    def limite(self):
        return self.__limite

    @limite.setter 
    def limite(self, limite):
        if limite < 0:
            print('Não foi possivel atualizar o limite \U0001F614.')
        else:
            self.__limite = limite

    def saldototal(self):
        return self.saldo + self.__limite
    
    def sacar(self, valor):
        if valor > self.saldototal():
            print("Não foi possivel sacar \U0001F614.")
        else:
            if valor <= self.saldo:
                self.__saldo -= valor
            else:
                self.limite -= (valor - self.saldo)
                self.salf = 0

class ContaPoupanca(Conta):

    def __init__(self, numero, nome, valor, rendimento):
        super().__init__(numero, nome, valor)
        self.__rendimento = rendimento

    @property
    def rendimento(self):
        return self.__rendimento

    @rendimento.setter
    def rendimento(self, rendimento):
        if rendimento < 0:
            print('Não foi possivel atualizar a taxa de rendimento \U0001F614.')
        else:
            self.__rendimento = rendimento

    def acaorendimento(self):
        self.saldo *= self.__rendimento
