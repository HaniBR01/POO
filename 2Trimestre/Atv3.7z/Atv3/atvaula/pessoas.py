class Pessoa:
    def __init__(self, nome, endereco):
        self.__nome = nome
        self.__endereco = endereco
    @property
    def nome(self):
        return self.__nome 
    @property
    def endereco(self):
        return self.__endereco
    @nome.setter
    def nome(self, nome):
        self.__nome = nome
    @endereco.setter
    def endereco(self, endereco):
        self.__endereco = endereco

class Aluno(Pessoa):
    def __init__(self, RA, nome, idade, endereco):
        super().__init__(nome, endereco)
        self.__RA = RA
        self.idade = idade

    @property
    def RA(self):
        return self.__RA        

class Professor(Pessoa):
    def __init__(self, nome, endereco, aula, matricula ):
        super().__init__(nome, endereco)
        self.__matricula = matricula
        self.listaAulas = []
        self.listaAulas += [aula]

    @property
    def matricula(self):
        return self. __matricula

    @matricula.setter
    def matricula(self, matricula):
        self.__matricula = matricula

    def addAula(self, aula):
        self.listaAulas += [aula]