class Aula:
    def __init__(self, data, horaInicio, horaFinal):
        self.__data = data
        self.horaInicio = horaInicio
        self.horaFinal = horaFinal
        self.listaPresenca = []

    def addAluno(self, aluno):
        if len(self.listaPresenca) == 40:
            print ("Não foi possível incluir aluno: Turma cheia! \N{pensive face}")
        else:
            self.listaPresenca += [aluno]

    @property
    def data(self):
        dia = self.  data.split("/")[0]
        mes = self.__data.split("/")[1]
        ano = self.  data.split("/")[2][2:]
        novaData = dia + "/" + mes + "/" + ano
        return novaData

    @data.setter
    def data(self, data):
        ano = data.split("/")[2]
        if len(ano) != 4:
            print("Não foi possível atualizar a data! \N{pensive face}")
        else:
            self.__data = data
            print(f"Data atualizada com sucesso! \N{grinning face with smiling eyes}")

    def registraPresenca(self, RA):
        print(f"{RA} esteve presente nesta aula. \N{grinning face}")