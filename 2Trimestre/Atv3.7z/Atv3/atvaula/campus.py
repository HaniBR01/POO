from pessoas import *
from recursos import Aula

d = input("\N{slightly smiling face} Informe a data da aula: ")
i = input("\N{slightly smiling face} Qual a hora inicial? ")
f = input("\N{slightly smiling face} Qual a hora final?")
a = Aula(d, i, f)

quantidade = 1
while quantidade <= 3:
    ra = input(f"\N{nerd face} Informe o RA do aluno {quantidade}: ")
    no = input(f"\N{nerd face} Informe o nome do aluno {quantidade}: ")
    an = input(f"\N{nerd face} Informe a idade do aluno {quantidade}: ")
    en = input(f"\N{nerd face} Informe o endereço o aluno {quantidade}: ")
    al = Aluno(ra, no, an, en)
    a.addAluno(al)
    quantidade += 1

m = int(input("\N{face with open mouth} Informe o numero de matricula: "))
n = input("\N{face with open mouth} Informe o nome do professor: ")
e = input("\N{face with open mouth} Qual o endereço? ")
p = Professor(n, e, a, m)

for aluno in a.listaPresenca:
    print(f"\N{neutral face} RA processado: {aluno.RA}")
    p.listaAulas[0].registraPresenca(aluno.RA)
print ("Lista de presença processada com sucesso! \N{winking face}")