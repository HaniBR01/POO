while True:
    try:
        numero = int(input('informe um numero: '))
        calculo = 1
        for i in range(1,numero + 1):
            calculo *= i
        print(f'o valor de fatorial de {numero} é {calculo}')
        print(x)
    except ValueError:
        print('calculo incorreto: você deve estar usando variavel a mais =(')
    except NameError:
        print('variavel x nem existe')
    try:
        x = int(input('informe o primeiro numero: '))
        y = int(input('informe o segundo numero: '))
        d = x/y
        print(f'o valor da divisão é {d:.2f}')
        break
    except ValueError:
        print('um dos valores estão errados! digite novamente!')
    except ZeroDivisionError:
        print('não pode dividir por zero, K7!')
    except:
        print('teste 1')