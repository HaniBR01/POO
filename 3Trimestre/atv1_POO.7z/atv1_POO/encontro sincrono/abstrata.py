from abc import ABC, abstractmethod

class Veiculo(ABC):

    def __init__(self, placa, cor):
        self.__placa = placa
        self.__cor = cor

    @property
    def placa(self):
        return self.__placa

    @property
    def cor(self):
        return self.__cor

    @abstractmethod
    def transferencia(self):
        pass

class Carro(Veiculo):

    def __init__(self, placa, cor, nomeFornecedor):
        super().__init__(placa, cor)
        self.__nomeFornecedor = nomeFornecedor

    @property
    def nomeFornecedor(self):
        return self.__nomeFornecedor

    def transferencia(self):
        print(f'carro transferido com sucesso para {self.__nomeFornecedor}')
        return "Valido até 2025"

carro = Carro("XXX-1111", "Marrom", "Zé Comeia")
print(carro.cor + " " + carro.transferencia())