from Banco.Carteira import *
from Banco.Conta import *
from Banco.Cliente import *
import os

if __name__ == "__main__":
    print ("Bem-vindo ao Bank POOdle \U0001F604\n")
    listaclientes = []
    listaCarteiras = []
    while True:
        
        print("\U0001F50E(1) Cadastrar um novo cliente. ")
        print("\U0001F50E(2) Pesquisar por um cliente existente. ")
        print("\U0001F50E(3) Cadastrar uma carteira para um cliente. ")
        print("\U0001F50E(4) Listar as contas de uma carteira existente ")
        print("\U0001F50E(5) Sair do programa. \n")
        
        while True:
            try:
                opcao = int(input("\U0001F50E Informe a opção desejada: "))
                break
            except ValueError:
                print("Erro, digite um valor inteiro")

        
        if opcao == 1:
            nome = input("\U0001F4BB Informe um nome para o cliente: ")
            while True:
                try:
                    dia = int(input("Dia de nascimento: "))
                    if (dia < 1) or (dia > 31):
                        print("esse dia não existe")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            while True:
                try:
                    mes = int(input("Mes de nascimento: "))
                    if (mes < 1) or (mes > 12):
                        print("esse mes não existe")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            while True:
                try:
                    ano = int(input("Ano de nascimento completo (YYYY): "))
                    if len(str(ano)) < 4:
                        print("Formato errado")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            datanascenca = f"{dia}/{mes}/{ano}"
            endereco = input("\U0001F4BB Informe o endereço do cliente: ")
            while True:
                t = input("\U0001F4BB O cliente trata-se de uma Pessoa Jurídica (J) ou uma Pessoa Física (F)? ")
                if t == ("J" or "j"):
                    cnpj = input("\U0001F4BB Informe o CNPJ: ")
                    cliente = PessoaJuridica(nome, datanascenca, endereco, cnpj)
                    listaclientes += [cliente]
                    break
                elif t == ("F" or "f"):
                    cpf = input("\U0001F4BB Informe o CPF: ")
                    cliente = PessoaFisica(nome, datanascenca, endereco, cpf)
                    listaclientes += [cliente]
                    break
                else:
                    print('Opção inválida! \U0001F61E')
        elif opcao == 2:
            dados = input('\U0001F4BB Informe o CNPJ ou o CPF do cliente: ')
            achou = False
            for cliente in listaclientes:
                if cliente.procuracliente()[3] == dados:
                    achou = True
                    print(cliente.retornacliente())
                    if cliente.listacarteira == []:
                        print('\U0001F50E O cliente não possui carteiras cadastradas, cadastre uma nova! ')
                        inv = input("\U0001F50E Qual o nome da carteira? ")
                        car = Carteira(inv)
                        resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                        while (resposta == "s"):
                            num = input("\U0001F4BB Informe o número da conta: ")
                            tit = input("\U0001F4BB Informe o nome do titular: " )
                            sld = float(input("\U0001F4BB Qual o valor do saldo inicial? "))
                            tip = input("\U0001F4BB Conta Corrente (C) ou Conta Poupança (P)? ")
                            if tip == "C":
                                car.addconta (ContaCorrente(num, tit, sld))
                            elif tip == "P":
                                ren = float(input("\U0001F4BB Qual o rendimento mensal? "))
                                car.addconta (ContaPoupanca(num, tit, sld, ren))
                            else:
                                print("opção invalida")
                            resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                        cliente.addcarteira(car)
                        listaCarteiras += [car]
                        print (f"Cadastro da carteira {inv} realizado com sucesso! \U0001F604\n")
                    else:
                        for carteira in cliente.listacarteira:
                            print(f"Contas na carteira {carteira.investimento}:\n")
                            for conta in carteira.listacontas:
                                print(conta.retornadados())
            if not achou:
                print("O cliente informado não existe \U0001F614.")
        elif opcao == 3:
            dados = input("\U0001F50E Informe o documento do cliente (CPF ou CNPJ): ")
            achou = False
            for cliente in listaclientes:
                if cliente.procuracliente()[3] == dados:
                    achou = True
                    inv = input("\U0001F50E Qual o nome da carteira? ")
                    car = Carteira(inv)
                    resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                    while (resposta == "s"):
                        num = input("\U0001F4BB Informe o número da conta: ")
                        tit = input("\U0001F4BB Informe o nome do titular: " )
                        sld = float(input("\U0001F4BB Qual o valor do saldo inicial? "))
                        tip = input("\U0001F4BB Conta Corrente (C) ou Conta Poupança (P)? ")
                        if tip == "C":
                            car.addconta (ContaCorrente(num, tit, sld))
                        elif tip == "P":
                            ren = float(input("\U0001F4BB Qual o rendimento mensal? "))
                            car.addconta (ContaPoupanca(num, tit, sld, ren))
                        else:
                            print("Opção invalida")
                        resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                    cliente.addcarteira(car)
                    listaCarteiras += [car]
                    print (f"Cadastro da carteira {inv} realizado com sucesso! \U0001F604\n")
            if not achou:
                    print("O cliente informado não existe. \U0001F614")   
        elif opcao == 4:
            inv = input("\U0001F4BB Informe a carteira que procura: ")
            achou = False
            for carteirinha in listaCarteiras:
                if carteirinha.investimento == inv:
                    achou = True
                    if carteirinha.listacontas == []:
                        print (" Essa carteira " + inv + " não possui contas cadastradas! \U0001F61E\n")
                    else:
                        for continha in carteirinha.listacontas:
                            print (continha.retornadados())
            if not achou:
                print ("Não existe essa carteira! \U0001F614")
            print ("\n")
        elif opcao == 5:
            break
        else:
            print ("Opção inválida! \U0001F614\n")
    
        input ()
        os.system("cls" if os.name == "nt" else "clear")
    print ("Volte sempre ao Bank POOdle \U0001F604")