import pymysql as MySQLbd

conexao = MySQLbd.connect(host="localhost", user="root", passwd="gabriel", db="teste")

banco = conexao.cursor()

banco.execute("select * from tabela;")

for linha in banco.fetchall():
    print(f'id: {linha[0]}\n texto: {linha[1]}\n\n')

banco.execute("insert into tabela values(3, 'mais teste');")
banco.execute("insert into tabela values(7, 'mais outro teste');")
banco.execute("commit;")

conexao.close()