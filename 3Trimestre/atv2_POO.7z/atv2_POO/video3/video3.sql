create database teste;
use teste;

create table tabela(
	id int not null,
    texto varchar(20),
    
    constraint pk_teste primary key (id)
);

insert into tabela values (5, 'teste');
insert into tabela values (8, 'outro teste');

select * from tabela;