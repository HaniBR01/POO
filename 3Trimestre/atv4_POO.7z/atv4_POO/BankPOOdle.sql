create database BankPOOdle;
use BankPOOdle;

create table Cliente (
	codigo int auto_increment not null,
    nome varchar(30) not null,
    dataNascimento varchar(12),
    endereco varchar(30),
    
    constraint pk_Cliente primary key (codigo)
);

create table PessoaFisica (
	codigoCliente int not null,
    CPF varchar(14) not null,
    
    constraint pk_PessoaFisica primary key (codigoCliente),
    constraint fk_ClientePessoaFisica foreign key (codigoCliente) references Cliente (codigo) on delete cascade
);

create table PessoaJuridica (
	codigoCliente int not null,
    CNPJ varchar(18) not null,
    
    constraint pk_PessoaJuridica primary key (codigoCliente),
    constraint fk_ClientePessoaJuridica foreign key (codigoCliente) references Cliente (codigo) on delete cascade
);

create table Carteira (
	codigoCliente int not null,
	codigo int auto_increment not null,
    investimento varchar(20) not null,
    
    constraint pk_Carteira primary key (codigo),
    constraint fk_CarteiraCliente foreign key (codigoCliente) references Cliente (codigo) on delete restrict
);

create table Conta (
	codigoCarteira int not null,
	numero int not null,
	saldo double not null,
    titular varchar(20) not null,
    
    constraint pk_Conta primary key (numero),
    constraint fk_CarteiraConta foreign key(codigoCarteira) references Carteira (codigo) on delete restrict
);

create table contaCorrente ( 
	numeroConta int not null,
    limite double not null,
    
    constraint pk_contaCorrente primary key (numeroConta),
    constraint fk_contaCorrente foreign key (numeroConta) references Conta (numero) on delete cascade
);

create table contaPoupanca ( 
	numeroConta int not null,
    rendimento double not null,
    
    constraint pk_contaPoupanca primary key (numeroConta),
    constraint fk_contaPoupanca foreign key (numeroConta) references Conta (numero) on delete cascade
);

#cliente
insert into Cliente(nome, dataNascimento, endereco) values('Glar Starag','02/10/1500','Guilda Caju');
insert into Cliente(nome, dataNascimento, endereco) values('Mindartes Liadon','28/02/1300','Guilda Caju');
insert into Cliente(nome, dataNascimento, endereco) values('Shamash Nemmonis','12/03/1500','Guilda Caju');
insert into Cliente(nome, dataNascimento, endereco) values('Niro Eryn','21/09/1450','Guilda Caju');
insert into Cliente(nome, dataNascimento, endereco) values('Draken Thokk','01/01/1500','Guilda Caju');

insert into PessoaFisica values(1,'000.000.000-00');
insert into PessoaFisica values(2,'000.000.000-01');
insert into PessoaFisica values(3,'000.000.000-02');
insert into PessoaFisica values(4,'000.000.000-03');
insert into PessoaFisica values(5,'000.000.000-04');

#carteira
insert into carteira(codigocliente, investimento) values (1,'Nubank');
insert into carteira(codigocliente, investimento) values (1,'Tesla');
insert into carteira(codigocliente, investimento) values (1,'BTC');
insert into carteira(codigocliente, investimento) values (2,'MegaSena');
insert into carteira(codigocliente, investimento) values (2,'Sportingbet');
insert into carteira(codigocliente, investimento) values (3,'Skol');
insert into carteira(codigocliente, investimento) values (4,'Petrobras');
insert into carteira(codigocliente, investimento) values (5,'LosPoiosHermanos');

#conta
#Glar
insert into conta values (1, 12345, 1000, 'Glar');
insert into contacorrente values(12345, 0);
insert into conta values (2, 12000, 900, 'Glar');
insert into contapoupanca values(12000, 2.50);
insert into conta values (2, 12001, 5000, 'Glar');
insert into contapoupanca values(12001, 1.25);
insert into conta values (2, 12002, 1000, 'Glar');
insert into contapoupanca values(12002, 1.05);
insert into conta values (3, 14444, 1000000000, 'Glar');
insert into contapoupanca values(14444, 6.00);
#mindartes
insert into conta values (4, 11111, 86, 'Mindartes');
insert into contapoupanca values(11111, 0.00);
insert into conta values (4, 32601, 86, 'Mindartes');
insert into contapoupanca values(32601, 0.00);
insert into conta values (4, 61012, 86, 'Mindartes');
insert into contapoupanca values(61012, 0.00);
insert into conta values (5, 01001, 12, 'Mindartes');
insert into contapoupanca values(01001, 2.00);
insert into conta values (5, 05000, 1000, 'Mindartes');
insert into contapoupanca values(05000, 0.00);
insert into conta values (5, 03003, 10, 'Mindartes');
insert into contapoupanca values(03003, 0.00);

#shamash
insert ignore conta values (6, 00001, 2440, 'Shamash');
insert into contacorrente values(00001, 0);
insert into conta values (6, 00002, 1230, 'Shamash');
insert into contapoupanca values(00002, 2.00);
insert into conta values (6, 00003, 450, 'Shamash');
insert into contapoupanca values(00003, 5.20);

#niro
insert into conta values (7, 00006, 36892, 'Niro');
insert into contacorrente values(00006, 0);
insert into conta values (7, 00007, 2578, 'Niro');
insert into contapoupanca values(00007, 2.32);
insert into conta values (7, 00008, 3456, 'Niro');
insert into contapoupanca values(00008, 7.12);