from datetime import *
import abc

class Cliente(abc.ABC):

    def __init__(self, nome, data, endereco):# metodo construtor da classe "mae" cliente para guardar dados
        self.__nome = nome
        self.__dataNascimento = data
        self.__endereco = endereco
        self.__listacarteira = []

    @property# retorna o nome
    def nome(self):
        return self.__nome

    @nome.setter# permite alterar o nome do cliente
    def nome(self, nome):
        self.__nome = nome

    @property# mostra a data de nascimento
    def dataNascimento(self):
        return self.__dataNascimento

    @property# retorna o endereço
    def endereco(self):
        return self.__endereco
    
    @endereco.setter# Altera o endereço do cliente
    def endereco(self, endereco):
        self.__endereco = endereco

    @property
    def listacarteira(self):
        return self.__listacarteira

    @listacarteira.setter
    def listacarteira(self, conta):
        self.__listacarteira += [conta]

    @abc.abstractclassmethod
    def retornacliente(self):
        pass

    @abc.abstractclassmethod
    def addcarteira(self):
        pass
    
    @abc.abstractclassmethod
    def procuracliente(self):
        pass

class PessoaFisica(Cliente):
    
    def __init__(self, nome, data, endereco, cpf):# metodo construtor da subclasse PessoaFisica(cliente) utilizando dados da calasse cliente
        super().__init__(nome, data, endereco)
        self.__cpf = cpf

    @property# retorna o cpf
    def cpf(self):
        return self.__cpf

    def maiorlegal(self):# importando a biblioteca datetime foi criado esse codigo com o objetivo de facilitar a determinação de maior idade ou nao
        DataNascimento = self.dataNascimento.split("/")
        x = date.today()# recebe a data atual
        x = x.strftime('%d/%m/%Y')
        x = x.split("/")
        if ((int(x[2])) - (int(DataNascimento[2]))) < 18:# se a diferença de anos da atua data e da data de nascimento for menor que 18 retorna falso
            return False 
        elif (((int(x[2])) - (int(DataNascimento[2]))) == 18) and ((int(x[1])) < (int(DataNascimento[1]))):
            return False# se a a diferença entre os anos for igual a 18, então e utilizado a diferenca em.
        elif (((int(x[2])) - (int(DataNascimento[2]))) == 18) and ((int(x[1])) == (int(DataNascimento[1]))) and ((int(x[0])) < (int(DataNascimento[0]))):
            return False# caso o ano e o mes forem igual é utilizado a diferenca em dias 
        else:
            return True # caso nao ocorra nenhum dos ultimos casos entao o cliente e maior de idade e é retornado true

    def procuracliente(self): # Codigo para procurar um cliente 
        return [self.nome, self.dataNascimento, self.endereco, self.__cpf]

    def retornacliente(self):# retorna todos os dados do cliente em uma string para facilitar a visualização desses dados
        return f"\U0001F4B8 Nome: {self.nome}\n\U0001F4B8 Data: {self.dataNascimento}\n\U0001F4B8 Endereco: {self.endereco}\n\U0001F4F1 CPF: {self.cpf}\n Maior legal? {self.maiorlegal()}\n\n"

    def addcarteira(self, carteira):# Metodo para adicionar carteira
        self.listacarteira.append(carteira)

class PessoaJuridica(Cliente):
    
    def __init__(self, nome, data, endereco, cnpj):# metodo construtor da subclasse PessoaJuridica(cliente), utilizando dados da calasse cliente
        super().__init__(nome, data, endereco)
        self.__cnpj = cnpj

    @property# retorna o cnpj
    def cnpj(self):
        return self.__cnpj

    def addcarteira(self, carteira):# Metodo para adicionar carteira
        self.listacarteira.append(carteira)

    def procuracliente(self):# Codigo para procurar um cliente 
        return [self.nome, self.dataNascimento, self.endereco, self.__cnpj]

    def retornacliente(self):# retorna todos os dados do cliente em uma string para facilitar a visualização desses dados
        return f"\U0001F4B8 Nome: {self.nome}\n\U0001F4B8 Data: {self.dataNascimento}\n\U0001F4B8 Endereco: {self.endereco}\n\U0001F4F1 CNPJ: {self.cnpj}\n\n"
