from datetime import *
import abc
 
class Conta(abc.ABC):

    def __init__(self, numero, nome, valor):# metodo construtor da classe "mae" conta
        self.__numero = numero
        self.__titular = nome
        self.__saldo = valor

    @property# retorna o numero
    def numero(self):
        return self.__numero

    @property# retorna o titular
    def titular(self): 
        partesNomes = self.__titular.split(" ")
        tamanho = len(partesNomes)
        return partesNomes[0] + " " + partesNomes[tamanho - 1]
    
    @titular.setter# Codigo para fazer alterações no nome do titular
    def titular(self, nome): 
        self.__titular = nome

    @property# retorna o saldo
    def saldo(self): 
        return self.__saldo

    @saldo.setter# Codigo para fazer alterações no saldo
    def saldo(self, valor):
        if valor < 0:
            print ("Não foi possível alterar o saldo! \U0001F614")
        else:
            self.__saldo = valor

    @abc.abstractmethod
    def sacar(self, valor):# Codigo para sacar um valor do saldo
        pass

    @abc.abstractmethod
    def depositar(self, valor):# Codigo para fazer depositos ao saldo
        pass

    @abc.abstractmethod
    def todosdados(self):
        pass

    @abc.abstractmethod
    def retornadados(self):# retorna todos os dados em uma string, para facilitar a apresentação dos dados
        pass

class ContaCorrente(Conta):

    def __init__(self, numero, nome, valor):# metodo construtor da subclasse ContaCorrente(Conta) usa dados da classe conta
        super().__init__(numero, nome, valor)
        self.__limite = 2000

    @property# retorna um limite
    def limite(self):
        return self.__limite

    @limite.setter# Codigo para alterar o valor do limite
    def limite(self, limite): 
        if (limite < 0):
            print ("Não foi possível alterar o limite! \U0001F614")
        else:
            self.__limite = limite

    def saldototal(self):#Codigo para retorna o saldo atual + o limite
        return self.saldo + self.__limite

    def sacar(self, valor):# Codigo paraa sacar, mais dessa vez com o valor do limite
        if (valor > self.saldototal()):
            print("Não foi possivel sacar esse valor! \U0001F614")
        elif (valor <= self.saldo):
            self.__saldo -= valor
        else:
            self.limite = (valor - self.saldo)
            self.saldo = 0

    def depositar(self, valor):# Codigo para fazer depositos ao saldo
        if (valor < 0):
            print ("Não foi possível realizar o depósito! \U0001F614")
        else:
            self.__saldo += valor

    def todosdados(self):
        return [self.numero,self.titular,self.saldo,self.limite]

    def retornadados(self):# retorna todos os dados em uma string, para facilitar a apresentação dos dados
        return f"\U0001F4B8 Número: {self.numero}\n\U0001F4B8 Nome do Titular: {self.titular}\n\U0001F4B8 Saldo da Conta: {self.saldo}\n\n\U0001F4B8 Limite: {self.limite} \n\n"

class ContaPoupanca(Conta):

    def __init__(self, numero, nome, valor, rendimento):# metodo construtor da subclasse ContaPoupanca(Conta) usa dados da classe conta
        super().__init__(numero, nome, valor)
        self.__rendimento = rendimento

    @property# retorna o rendimento
    def rendimento(self):
        return self.__rendimento

    @rendimento.setter# Codigo para alterar o rendimento da conta poupanca
    def rendimento(self, rendimento): 
        if (rendimento < 0):
            print ("Não foi possível alterar a taxa de rendimento! \U0001F620")
        else:
            self.__rendimento = rendimento

    def acaorendimento(self):# Codigo para o rendimento render no saldo
        self.saldo *= self.__rendimento 

    def sacar(self, valor):# Codigo para sacar um valor do saldo
        if (valor > self.__saldo):
            print("Não foi possivel sacar esse valor! \U0001F614")
        else:
            self.__saldo -= valor 

    def depositar(self, valor):# Codigo para fazer depositos ao saldo
        if (valor < 0):
            print ("Não foi possível realizar o depósito! \U0001F614")
        else:
            self.__saldo += valor

    def todosdados(self):
        return [self.numero,self.titular,self.saldo,self.limite]

    def retornadados(self):# retorna todos os dados em uma string, para facilitar a apresentação dos dados
        return f"\U0001F4B8 Número: {self.numero} \n\U0001F4B8 Nome do Titular: {self.titular}\n\U0001F4B8 Saldo da Conta: {self.saldo} \n\n\U0001F4B8 Rendimento: {self.rendimento}\n\n"
