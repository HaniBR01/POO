class Carteira:

    def __init__(self, investimento):# metodo construtor para a classe carteira guardar dados
        self.__investimento = investimento
        self.__listacontas = []

    @property # retorna o investimento
    def investimento(self):
        return self.__investimento

    @investimento.setter# seta um nome para o investimento
    def investimento(self, valor):
        self.__investimento = valor

    @property# retorna a lista de contas
    def listacontas(self):
        return self.__listacontas

    def retornadado(self):
        return self.investimento

    def addconta(self, objetoconta):# adiciona uma conta, mai tem um limite de no maximo 3 contas.
        if len(self.__listacontas) == 3:
            print ("Não é possivel ter mais de 3 contas! \U0001F614")
        else:
            self.__listacontas.append(objetoconta)
    
    def contasnegativas(self):#Codigo para mostrar as contas com saldo negativo
        listanegativas = []
        for continha in self.__listacontas:
            if continha.saldo < 0:
                listanegativas += [continha]
        if len(listanegativas) == 0:
            print ("Nenhuma conta está negativa nessa carteira! \U0001F601")
            return listanegativas
