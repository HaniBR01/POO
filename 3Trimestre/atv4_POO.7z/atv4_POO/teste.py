from Banco.Carteira import *
from Banco.Conta import *
from Banco.Cliente import *
import os

import pymysql as MySQLbd

conexao = MySQLbd.connect(host="localhost", user="root", passwd="admin", db="bankpoodle")

listaclientes = []
listaCarteiras = []
listaConta = []

banco = conexao.cursor()
banco.execute("select c.codigo, c.nome, c.datanascimento, c.endereco from cliente c;")
cliente = banco.fetchall()
banco.execute("select f.codigocliente, f.cpf from pessoafisica f;")
pessoafisica = banco.fetchall()
banco.execute("select j.codigocliente, j.cnpj from pessoajuridica j;")
pessoajuridica = banco.fetchall()
banco.execute("select c.codigocliente, c.codigo, c.investimento from carteira c;")
carteira = banco.fetchall()
banco.execute("select c.codigocarteira, c.numero, c.saldo, c.titular from conta c;")
conta = banco.fetchall()
banco.execute("select p.numeroconta, p.rendimento from contapoupanca p;")
contapoupanca = banco.fetchall()
banco.execute("select c.numeroconta, c.limite from contacorrente c;")
contacorrente = banco.fetchall()
banco.close()
for cli in cliente:
    for fis in pessoafisica:
        if cli[0] == fis[0]:
            clt = PessoaFisica(cli[1],cli[2],cli[3],fis[1])
            listaclientes.append(clt)
    for jur in pessoajuridica:
        if cli[0] == jur[0]:
            clt = PessoaJuridica(cli[1],cli[2],cli[3],jur[1])
            listaclientes.append(clt)
    for car in carteira:
        if car[0] == cli[0]:
            crt = Carteira(car[2])
            print(crt.investimento)
            listaCarteiras.append(crt)
            clt.addcarteira(crt)
            for con in conta:
                for cor in contacorrente:
                    if (con[1] == cor[0]) and (con[0] == car[1]):
                            cnt = ContaCorrente(con[1], con[3], con[2])
                            #cnt.limite(1000)
                            crt.addconta(cnt)
                            listaConta.append(cnt)
                for pou in contapoupanca:
                    if (con[1] == pou[0]) and (con[0] == car[1]):
                            cnt = ContaPoupanca(con[1], con[3], con[2], pou[1])
                            crt.addconta(cnt)
                            listaConta.append(cnt)

            
for cliente in listaclientes:
    for carteira in cliente.listacarteira:
        print(carteira.investimento)