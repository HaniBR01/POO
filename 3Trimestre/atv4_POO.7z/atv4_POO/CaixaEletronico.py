from Banco.Carteira import *
from Banco.Conta import *
from Banco.Cliente import *
import os

import pymysql as MySQLbd

conexao = MySQLbd.connect(host="localhost", user="root", passwd="admin", db="bankpoodle")

if __name__ == "__main__":
    print ("Bem-vindo ao Bank POOdle \U0001F604\n")
    listaclientes = []
    listaCarteiras = []
    listaConta = []

    banco = conexao.cursor()
    banco.execute("select c.codigo, c.nome, c.datanascimento, c.endereco from cliente c;")
    cliente = banco.fetchall()
    banco.execute("select f.codigocliente, f.cpf from pessoafisica f;")
    pessoafisica = banco.fetchall()
    banco.execute("select j.codigocliente, j.cnpj from pessoajuridica j;")
    pessoajuridica = banco.fetchall()
    banco.execute("select c.codigocliente, c.codigo, c.investimento from carteira c;")
    carteira = banco.fetchall()
    banco.execute("select c.codigocarteira, c.numero, c.saldo, c.titular from conta c;")
    conta = banco.fetchall()
    banco.execute("select p.numeroconta, p.rendimento from contapoupanca p;")
    contapoupanca = banco.fetchall()
    banco.execute("select c.numeroconta, c.limite from contacorrente c;")
    contacorrente = banco.fetchall()
    banco.close()
    for cli in cliente:
        for fis in pessoafisica:
            if cli[0] == fis[0]:
                clt = PessoaFisica(cli[1],cli[2],cli[3],fis[1])
                listaclientes.append(clt)
        for jur in pessoajuridica:
            if cli[0] == jur[0]:
                clt = PessoaJuridica(cli[1],cli[2],cli[3],jur[1])
                listaclientes.append(clt)
        for car in carteira:
            if car[0] == cli[0]:
                crt = Carteira(car[2])
                listaCarteiras.append(crt)
                clt.addcarteira(crt)
                for con in conta:
                    for cor in contacorrente:
                        if (con[1] == cor[0]) and (con[0] == car[1]):
                                cnt = ContaCorrente(con[1], con[3], con[2])
                                #cnt.limite(1000)
                                crt.addconta(cnt)
                                listaConta.append(cnt)
                    for pou in contapoupanca:
                        if (con[1] == pou[0]) and (con[0] == car[1]):
                                cnt = ContaPoupanca(con[1], con[3], con[2], pou[1])
                                crt.addconta(cnt)
                                listaConta.append(cnt)


    while True:
        
        print("\U0001F50E(1) Cadastrar um novo cliente. ")
        print("\U0001F50E(2) Pesquisar por um cliente existente. ")
        print("\U0001F50E(3) Cadastrar uma carteira para um cliente. ")
        print("\U0001F50E(4) Listar as contas de uma carteira existente ")
        print("\U0001F50E(5) Sair do programa. \n")
        
        while True:
            try:
                opcao = int(input("\U0001F50E Informe a opção desejada: "))
                break
            except ValueError:
                print("Erro, digite um valor inteiro")
        
        if opcao == 1:
            nome = input("\U0001F4BB Informe um nome para o cliente: ")
            while True:
                try:
                    dia = int(input("Dia de nascimento: "))
                    if (dia < 1) or (dia > 31):
                        print("esse dia não existe")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            while True:
                try:
                    mes = int(input("Mes de nascimento: "))
                    if (mes < 1) or (mes > 12):
                        print("esse mes não existe")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            while True:
                try:
                    ano = int(input("Ano de nascimento completo (YYYY): "))
                    if len(str(ano)) < 4:
                        print("Formato errado")
                    else:
                        break
                except ValueError:
                    print("Digite numeros inteiros")
            datanascenca = f"{dia:0>2}/{mes:0>2}/{ano}"
            endereco = input("\U0001F4BB Informe o endereço do cliente: ")
            banco = conexao.cursor()
            banco.execute(f"insert into cliente(nome, datanascimento, endereco) values('{nome}', '{datanascenca}', '{endereco}');")
            while True:
                t = input("\U0001F4BB O cliente trata-se de uma Pessoa Jurídica (J) ou uma Pessoa Física (F)? ")
                if (t == "J") or (t == "j"):
                    cnpj = input("\U0001F4BB Informe o CNPJ: ")
                    cliente = PessoaJuridica(nome, datanascenca, endereco, cnpj)
                    listaclientes += [cliente]
                    banco.execute(f"insert into pessoajuridica select MAX(c.codigo), '{cnpj}' from cliente c;")
                    break
                elif (t == "F") or (t =="f"):
                    cpf = input("\U0001F4BB Informe o CPF: ")
                    cliente = PessoaFisica(nome, datanascenca, endereco, cpf)
                    listaclientes += [cliente]
                    banco.execute(f"insert into pessoafisica select MAX(c.codigo), '{cpf}' from cliente c;")
                    break
                else:
                    print('Opção inválida! \U0001F61E')
            banco.execute("commit;")
            banco.close()
        elif opcao == 2:
            banco = conexao.cursor()
            dados = input('\U0001F4BB Informe o CNPJ ou o CPF do cliente: ')
            achou = False
            for cliente in listaclientes:
                if cliente.procuracliente()[3] == dados:
                    achou = True
                    print(cliente.retornacliente())
                    if cliente.listacarteira == []:
                        print('\U0001F50E O cliente não possui carteiras cadastradas, cadastre uma nova! ')
                        inv = input("\U0001F50E Qual o nome da carteira? ")
                        car = Carteira(inv)
                        banco.execute(f"insert into carteira(codigocliente, investimento)   select c.codigo, '{inv}'\n" +
                                                                                            "from cliente c, pessoafisica f\n" +
                                                                                            f"where c.codigo = f.codigocliente and f.cpf = '{dados}'\n"+
                                                                                            "union\n"
                                                                                            f"select c.codigo, '{inv}'\n"+
                                                                                            "from cliente c, pessoajuridica j\n"+
                                                                                            f"where c.codigo = j.codigocliente and j.cnpj = '{dados}';")
                        resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                        while (resposta == "s"):
                            while True:
                                try:
                                    num = int(input("\U0001F4BB Informe o número da conta: "))
                                    break
                                except ValueError:
                                    print("Digite um número inteiro!")
                            tit = input("\U0001F4BB Informe o nome do titular: " )
                            while True:
                                try:
                                    sld = float(input("\U0001F4BB Qual o valor do saldo inicial? "))
                                    break
                                except ValueError:
                                    print("Digite um valor real")
                            tip = input("\U0001F4BB Conta Corrente (C) ou Conta Poupança (P)? ")
                            try:
                                banco.execute(f"insert into conta(codigocarteira, numero, titular, saldo)  select c.codigo, {num}, '{tit}', {sld}\n"+
                                                                                                           "from carteira c, cliente t\n"+
                                                                                                           f"where c.investimento = '{inv}' and t.codigo = c.codigocliente;")
                            except MySQLbd.err.IntegrityError:
                                print("Erro de integridade, consulte o administrador")
                            if tip == "C":
                                try:
                                    banco.execute(f"insert into contacorrente(numeroconta, limite)  select c.numero, 2000\n"+
                                                                                                "from conta c\n"+
                                                                                                f"where c.numero = {num};")
                                    car.addconta (ContaCorrente(num, tit, sld))
                                except MySQLbd.err.IntegrityError:
                                        print("Erro de integridade, consulte o administrador")
                            elif tip == "P":
                                while True:
                                    try:
                                        ren = float(input("\U0001F4BB Qual o rendimento mensal? "))
                                        break
                                    except ValueError:
                                        print("Digite um valor real")
                                try:
                                    banco.execute(f"insert into contapoupanca(numeroconta, rendimento)  select c.numero, {ren}\n"+
                                                                                                    "from conta c\n"+
                                                                                                    f"where c.numero = {num};")
                                    car.addconta (ContaPoupanca(num, tit, sld, ren))
                                except MySQLbd.err.IntegrityError:
                                    print("Erro de integridade, consulte o administrador")
                            else:
                                print("opção invalida")
                            resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                        cliente.addcarteira(car)
                        listaCarteiras += [car]
                        print (f"Cadastro da carteira {inv} realizado com sucesso! \U0001F604\n")
                    else:
                        for carteira in cliente.listacarteira:
                            print(f"Contas na carteira {carteira.investimento}:\n")
                            for conta in carteira.listacontas:
                                print(conta.retornadados())
            if not achou:
                print("O cliente informado não existe \U0001F614.")
            banco.execute("commit;")
            banco.close()
        elif opcao == 3:
            banco = conexao.cursor()
            dados = input("\U0001F50E Informe o documento do cliente (CPF ou CNPJ): ")
            achou = False
            for cliente in listaclientes:
                if cliente.procuracliente()[3] == dados:
                    achou = True
                    inv = input("\U0001F50E Qual o nome da carteira? ")
                    car = Carteira(inv)
                    banco.execute(f"insert into carteira(codigocliente, investimento)   select c.codigo, '{inv}'\n" +
                                                                                        "from cliente c, pessoafisica f\n" +
                                                                                        f"where c.codigo = f.codigocliente and f.cpf = '{dados}'\n"+
                                                                                        "union\n"
                                                                                        f"select c.codigo, '{inv}'\n"+
                                                                                        "from cliente c, pessoajuridica j\n"+
                                                                                        f"where c.codigo = j.codigocliente and j.cnpj = '{dados}';")
                    resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                    while (resposta == "s"):
                        while True:
                            try:
                                num = int(input("\U0001F4BB Informe o número da conta: "))
                                break
                            except ValueError:
                                print("Digite um número inteiro!")
                        tit = input("\U0001F4BB Informe o nome do titular: " )
                        while True:
                            try:
                                sld = float(input("\U0001F4BB Qual o valor do saldo inicial? "))
                                break
                            except ValueError:
                                print("Digite um valor real")
                        tip = input("\U0001F4BB Conta Corrente (C) ou Conta Poupança (P)? ")
                        try:
                            banco.execute(f"insert into conta(codigocarteira, numero, titular, saldo)  select c.codigo, {num}, '{tit}', {sld}\n"+
                                                                                                "from carteira c, cliente t\n"+
                                                                                                f"where c.investimento = '{inv}' and t.codigo = c.codigocliente;")
                        except MySQLbd.err.IntegrityError:
                                print("Erro de integridade, consulte o administrador")
                        
                        if tip == "C":
                            try:
                                banco.execute(f"insert into contacorrente(numeroconta, limite)  select c.numero, 2000\n"+
                                                                                                "from conta c\n"+
                                                                                                f"where c.numero = {num};")
                                car.addconta (ContaCorrente(num, tit, sld))
                            except MySQLbd.err.IntegrityError:
                                print("Erro de integridade, consulte o administrador")
                        elif tip == "P":
                            while True:
                                try:
                                    ren = float(input("\U0001F4BB Qual o rendimento mensal? "))
                                    break
                                except ValueError:
                                    print("Digite um valor real")
                            try:
                                banco.execute(f"insert into contapoupanca(numeroconta, rendimento)  select c.numero, {ren}\n"+
                                                                                                    "from conta c\n"+
                                                                                                    f"where c.numero = {num};")
                                car.addconta (ContaPoupanca(num, tit, sld, ren))
                            except MySQLbd.err.IntegrityError:
                                print("Erro de integridade, consulte o administrador")
                        else:
                            print("Opção invalida")
                        resposta = input("\U0001F50E Deseja cadastrar uma conta? (s/n) ")
                    cliente.addcarteira(car)
                    listaCarteiras += [car]
                    print (f"Cadastro da carteira {inv} realizado com sucesso! \U0001F604\n")
            if not achou:
                    print("O cliente informado não existe. \U0001F614")   
            banco.execute("commit;")
            banco.close()
        elif opcao == 4:
            banco = conexao.cursor()
            inv = input("\U0001F4BB Informe a carteira que procura: ")
            achou = False
            for carteirinha in listaCarteiras:
                if carteirinha.investimento == inv:
                    achou = True
                    if carteirinha.listacontas == []:
                        print (" Essa carteira " + inv + " não possui contas cadastradas! \U0001F61E\n")
                    else:
                        for continha in carteirinha.listacontas:
                            print (continha.retornadados())
            if not achou:
                print ("Não existe essa carteira! \U0001F614")
            print ("\n")
            banco.execute("commit;")
            banco.close()
        elif opcao == 5:
            break
        else:
            print ("Opção inválida! \U0001F614\n")
        
    
        input ()
        os.system("cls" if os.name == "nt" else "clear")
    print ("Volte sempre ao Bank POOdle \U0001F604")